var user=prompt("Please input your name?");
switch(user){
	case "Meidi":
		document.write("<p id=\"deviceready\">Welcome back!</p>");
		break;
	default:
		document.write("<p id=\"deviceready\">Welcome new user!</p>");
}


